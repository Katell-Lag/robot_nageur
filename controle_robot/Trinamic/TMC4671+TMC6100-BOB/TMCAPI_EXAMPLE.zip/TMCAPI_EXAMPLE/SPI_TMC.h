/*
 * SPI_TMC.h
 *
 *  Created on: 12.01.2018
 *      Author: MN
 */
#ifndef SPI_TMC_H
#define SPI_TMC_H

#include "TMC-API/tmc/helpers/API_Header.h"

void initSPI(void);

// TMC4671 SPI wrapper
void tmc4671_writeDatagram(uint8 motor, uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);
void tmc4671_writeInt(uint8 motor, uint8 address, int value);
int tmc4671_readInt(u8 motor, uint8 address);

// General SPI functions
void tmc40bit_writeInt(u8 motor, uint8 address, int value);
int tmc40bit_readInt(u8 motor, uint8 address);

#endif /* SPI_TMC_H */