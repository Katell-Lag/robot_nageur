# Created on: 23.03.2020
# Author: LK

class Feature(object):
    def __init__(self, module):
        self._module = module
