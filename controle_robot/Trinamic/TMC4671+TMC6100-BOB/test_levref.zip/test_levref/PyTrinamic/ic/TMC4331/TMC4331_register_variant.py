'''
Created on 06.02.2020

@author: JM
'''

class TMC4331_register_variant:

    " ===== TMC4331 register variants ===== "
    "..."