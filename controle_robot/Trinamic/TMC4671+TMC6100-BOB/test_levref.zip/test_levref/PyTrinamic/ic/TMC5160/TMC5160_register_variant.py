'''
Created on 24.10.2019

@author: JM
'''

class TMC5160_register_variant:

    " ===== TMC5160 register variants ===== "
    "..."