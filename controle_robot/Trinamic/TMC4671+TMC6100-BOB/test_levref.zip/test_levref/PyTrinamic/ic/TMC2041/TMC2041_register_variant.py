'''
Created on 24.10.2019

@author: JM
'''

class TMC2041_register_variant:

    " ===== TMC2041 register variants ===== "
    "..."