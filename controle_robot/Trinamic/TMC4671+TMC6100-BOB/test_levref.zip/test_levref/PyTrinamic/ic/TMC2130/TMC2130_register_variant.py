'''
Created on 14.10.2019

@author: JM
'''

class TMC2130_register_variant:

    " ===== TMC2130 register variants ===== "
    "..."