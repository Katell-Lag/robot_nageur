'''
Created on 07.11.2019

@author: JM
'''

class TMC4361_register_variant:

    " ===== TMC4361 register variants ===== "
    "..."