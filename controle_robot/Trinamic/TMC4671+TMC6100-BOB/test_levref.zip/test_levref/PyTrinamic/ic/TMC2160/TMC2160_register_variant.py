'''
Created on 23.10.2019

@author: JM
'''

class TMC2160_register_variant:

    " ===== TMC2160 register variants ===== "
    "..."