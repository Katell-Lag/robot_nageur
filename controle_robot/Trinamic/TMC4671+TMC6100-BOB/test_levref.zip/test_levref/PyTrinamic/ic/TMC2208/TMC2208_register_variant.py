'''
Created on 17.10.2019

@author: JM
'''

class TMC2208_register_variant:

    " ===== TMC2208 register variants ===== "
    "..."