'''
Created on 31.01.2020

@author: JM
'''

class TMC6100_register_variant:

    " ===== TMC6100 register variants ===== "
    "..."