'''
Created on 07.11.2019

@author: JM
'''

class TMC2660_register_variant:

    " ===== TMC2660 register variants ===== "
    "..."