'''
Created on 07.02.2020

@author: JM
'''

class TMC2590_register_variant:

    " ===== TMC2590 register variants ===== "
    "..."