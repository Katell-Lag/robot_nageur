'''
Created on 30.03.2020

@author: JM
'''

class TMC7300_register_variant:

    " ===== TMC7300 register variants ===== "
    "..."