'''
Created on 30.01.2020

@author: JM
'''

class TMC5161_register_variant:

    " ===== TMC5161 register variants ===== "
    "..."