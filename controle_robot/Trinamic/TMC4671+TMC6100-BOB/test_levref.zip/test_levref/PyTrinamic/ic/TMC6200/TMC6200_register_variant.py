'''
Created on 06.03.2019

@author: ed
'''

class TMC6200_register_variant:

    " ===== TMC6200 register variants ===== "
    "..."