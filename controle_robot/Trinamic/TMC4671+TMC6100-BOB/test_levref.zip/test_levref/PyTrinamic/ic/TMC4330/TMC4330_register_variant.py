'''
Created on 06.02.2020

@author: ED
'''

class TMC4330_register_variant:

    " ===== TMC4330 register variants ===== "
    "..."
