'''
Created on 29.01.2020

@author: JM
'''

class TMC5031_register_variant:

    " ===== TMC5031 register variants ===== "
    "..."