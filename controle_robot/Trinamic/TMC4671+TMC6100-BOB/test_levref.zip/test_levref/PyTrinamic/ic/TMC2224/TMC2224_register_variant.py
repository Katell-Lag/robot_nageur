'''
Created on 07.02.2020

@author: JM
'''

class TMC2224_register_variant:

    " ===== TMC2224 register variants ===== "
    "..."