'''
Created on 18.10.2019

@author: JM
'''

class TMC2209_register_variant:

    " ===== TMC2209 register variants ===== "
    "..."