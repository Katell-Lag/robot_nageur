'''
Created on 17.10.2019

@author: JM
'''

class TMC2225_register_variant:

    " ===== TMC2225 register variants ===== "
    "..."