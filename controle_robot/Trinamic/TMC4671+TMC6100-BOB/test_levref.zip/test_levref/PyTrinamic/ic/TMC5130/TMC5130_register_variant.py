'''
Created on 22.02.2019

@author: ed
'''

class TMC5130_register_variant:

    " ===== TMC5130 register variants ===== "
    "..."