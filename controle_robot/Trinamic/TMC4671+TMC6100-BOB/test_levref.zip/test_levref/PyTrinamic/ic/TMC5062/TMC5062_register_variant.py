'''
Created on 24.09.2019

@author: JM
'''

class TMC5062_register_variant:

    " ===== TMC5062 register variants ===== "
    "..."