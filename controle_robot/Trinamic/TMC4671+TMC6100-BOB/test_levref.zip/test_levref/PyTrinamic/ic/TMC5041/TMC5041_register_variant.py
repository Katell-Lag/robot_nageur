'''
Created on 18.04.2019

@author: LH
'''

class TMC5041_register_variant:

    " ===== TMC5041 register variants ===== "
    "..."