'''
Created on 20.09.2019

@author: JM
'''

class TMC5072_register_variant:

    " ===== TMC5072 register variants ===== "
    "..."