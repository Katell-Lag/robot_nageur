'''
Created on 15.10.2019

@author: JM
'''

class TMC2100_register_variant:

    " ===== TMC2100 register variants ===== "
    "..."