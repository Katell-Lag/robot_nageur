'''
Created on 15.10.2019

@author: JM
'''

class TMC2100_register:
    """
    Define all registers of the TMC2100.
    """
    GCONF  = 0x00