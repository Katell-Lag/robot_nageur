'''
Created on 27.03.2020

@author: JM
'''

class TMC2300_register_variant:

    " ===== TMC2300 register variants ===== "
    "..."