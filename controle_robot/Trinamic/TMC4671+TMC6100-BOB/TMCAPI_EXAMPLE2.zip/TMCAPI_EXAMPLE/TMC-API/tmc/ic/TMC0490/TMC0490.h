/*
 * TMC0490.h
 *
 *  Created on: 18.07.2016
 *      Author: bs, ed
 */

#ifndef API_IC_TMC0490_H
#define API_IC_TMC0490_H

	#include "../../helpers/API_Header.h"
	#include "TMC0490_Register.h"
	#include "TMC0490_Mask_Shift.h"

//	void tmc0490_init();
//	void tmc0490_periodicJob(u32 actualSystick);

#endif /* API_IC_TMC0490_H_ */
