#include <stdio.h>
#include <wiringPi.h>
#include <bcm2835.h>
#include "SPI_TMC.h"

// Include the IC(s) you want to use
#include "TMC-API/tmc/ic/TMC4671/TMC4671.h"


/*
// If using latest TMC-API, we need to provide this function and remove SPI_TMC.c/.h...

uint8_t tmc4671_readwriteByte(uint8_t motor, uint8_t data, uint8_t lastTransfer)
{
	// According to how it seems to be used in TMC4671.c, maybe this might be enough...
	char tbuf[1];
	if (data == 0)
	{
		return bcm2835_spi_transfer(data);
	}
	else
	{
		tbuf[0] = 0xFF & data;
		bcm2835_spi_writenb(tbuf, 1);
		return 0;
	}
}
*/


/* Call all standard initialization routines. */
static void init()
{
	// Motor type &  PWM configuration
	tmc4671_writeInt(0, TMC4671_MOTOR_TYPE_N_POLE_PAIRS, 0x00030008);
	tmc4671_writeInt(0, TMC4671_PWM_POLARITIES, 0x00000000);
	tmc4671_writeInt(0, TMC4671_PWM_MAXCNT, 0x00000F9F);
	tmc4671_writeInt(0, TMC4671_PWM_BBM_H_BBM_L, 0x00001919);
	tmc4671_writeInt(0, TMC4671_PWM_SV_CHOP, 0x00000007);

	// ADC configuration
	tmc4671_writeInt(0, TMC4671_ADC_I_SELECT, 0x09000100);
	tmc4671_writeInt(0, TMC4671_dsADC_MCFG_B_MCFG_A, 0x00100010);
	tmc4671_writeInt(0, TMC4671_dsADC_MCLK_A, 0x20000000);
	tmc4671_writeInt(0, TMC4671_dsADC_MCLK_B, 0x00000000);
	tmc4671_writeInt(0, TMC4671_dsADC_MDEC_B_MDEC_A, 0x014E014E);
	tmc4671_writeInt(0, TMC4671_ADC_I0_SCALE_OFFSET, 0x01008001);
	tmc4671_writeInt(0, TMC4671_ADC_I1_SCALE_OFFSET, 0x01008001);
	
	//ABN encoder settings
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_MODE, 0x00000000);
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_PPR, 0x014E014E);
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_COUNT, 0x01008001);
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, 0x01008001);
	
	//limits
	tmc4671_writeInt(0, TMC4671_PID_TORQUE_FLUX_LIMITS, 0x00000000);
	
	// PI settings
	tmc4671_writeInt(0, TMC4671_PID_TORQUE_P_TORQUE_I, 0x01000100);
	tmc4671_writeInt(0, TMC4671_PID_FLUX_P_FLUX_I, 0x01000100);

	// ===== ABN encoder test drive =====

	// Init encoder (mode 0)
	tmc4671_writeInt(0, TMC4671_MODE_RAMP_MODE_MOTION, 0x00000008);
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, 0x00000000);
	tmc4671_writeInt(0, TMC4671_PHI_E_SELECTION, 0x00000001);
	tmc4671_writeInt(0, TMC4671_PHI_E_EXT, 0x00000000);
	tmc4671_writeInt(0, TMC4671_UQ_UD_EXT, 0x000007D0);
	//delay(6);
	tmc4671_writeInt(0, TMC4671_ABN_DECODER_COUNT, 0x00000000);

	// Feedback selection
	tmc4671_writeInt(0, TMC4671_PHI_E_SELECTION, 0x00000003);
	tmc4671_writeInt(0, TMC4671_VELOCITY_SELECTION, 0x00000009);

	// Open loop settings
	tmc4671_writeInt(0, TMC4671_OPENLOOP_MODE, 0x00000000);
	tmc4671_writeInt(0, TMC4671_OPENLOOP_ACCELERATION, 0x0000003C);
	tmc4671_writeInt(0, TMC4671_OPENLOOP_VELOCITY_TARGET, 0xFFFFFFF6);

	// Feedback selection
	tmc4671_writeInt(0, TMC4671_PHI_E_SELECTION, 0x00000002);
	tmc4671_writeInt(0, TMC4671_UQ_UD_EXT, 0x00000A60);

	//Switch to torque mode
	tmc4671_writeInt(0, TMC4671_MODE_RAMP_MODE_MOTION, 0x00000001);

	printf("%d",tmc4671_readInt(0, TMC4671_ABN_DECODER_COUNT));

}

int main(int argc, char **argv) {
	if (!bcm2835_init())
      return 1;

	wiringPiSetupGpio();
  	
	// Initiate SPI 
	bcm2835_spi_begin();
	bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST); // MSB first
  	bcm2835_spi_setDataMode(BCM2835_SPI_MODE3); // SPI Mode 3
  	bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_256); // 1 MHz clock
  	bcm2835_spi_chipSelect(BCM2835_SPI_CS0); // define CS pin
	bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW); // set CS polarity to low
	

	/***** TMC4671-BOB Example *****/
	pinMode(2, OUTPUT);
	digitalWrite(2, HIGH); // Apply VCC_IO voltage to Motor 0
	pinMode(3, OUTPUT);
	//digitalWrite(3, LOW); // Use internal clock
	//pinMode(4, OUTPUT);
	//digitalWrite(4, LOW); // Enable driver stage
	digitalWrite(3, HIGH); // CTRL_EN?


	// Autres pins � mettre � HIGH ou LOW?


	init();

	// Main loop
	while(1)
	{
		//tmc4671_setTargetTorque_raw(0,200);
		tmc4671_writeInt(0, TMC4671_PID_TORQUE_FLUX_TARGET, 0x03E80000);
		delay(140);
		//printf("rotate right\n");
		
		//printf("%d",tmc4671_readInt(0, TMC4671_ABN_DECODER_COUNT));

		tmc4671_writeInt(0, TMC4671_PID_TORQUE_FLUX_TARGET, 0x03E80000);
		tmc4671_writeInt(0, TMC4671_PID_TORQUE_FLUX_TARGET, 0x03E80000);
		delay(120);

/*
	// Rotate left
	tmc4671_writeInt(0, TMC4671_OPENLOOP_VELOCITY_TARGET, 0xFFFFFFC4);
	sleep(4);
	printf("rotate left\n");

	// Stop
	tmc4671_writeInt(0, TMC4671_OPENLOOP_VELOCITY_TARGET, 0x00000000);
	sleep(2);
	printf("stop\n");
	tmc4671_writeInt(0, TMC4671_UQ_UD_EXT, 0x00000000);*/
	}

	// End SPI communication
  	bcm2835_spi_end();
   	bcm2835_close();

	return 0;
}
