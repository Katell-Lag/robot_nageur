#include <bcm2835.h>
#include "SPI_TMC.h"


// TMC4671 SPI wrapper
void tmc4671_writeDatagram(uint8 motor, uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4)
{
    int value = x1;
	value <<= 8;
	value |= x2;
	value <<= 8;
	value |= x3;
	value <<= 8;
	value |= x4;

    tmc40bit_writeInt(motor, address, value);
}

void tmc4671_writeInt(u8 motor, uint8 address, int value)
{
    tmc40bit_writeInt(motor, address, value);
}

int tmc4671_readInt(u8 motor, uint8 address)
{
    tmc40bit_readInt(motor, address);
    return tmc40bit_readInt(motor, address);
}

u16 tmc4671_readRegister16BitValue(u8 motor, u8 address, u8 channel)
{
    char tbuf[3], rbuf[3];
    u16 value;
	// clear write bit
	tbuf[0] = address & 0x7F;
    tbuf[1] = 0;
    tbuf[2] = 0;
    
    bcm2835_spi_transfernb (tbuf, rbuf, 3);

	value =rbuf[1];
	value <<= 8;
	value |= rbuf[2];

	return value;
}

void tmc4671_writeRegister16BitValue(u8 motor, u8 address, u8 channel, u16 value)
{
    char tbuf[3];
    tbuf[0] = address | 0x80;
    tbuf[1] = 0xFF & (value>>8);
    tbuf[2] = 0xFF & value;

    bcm2835_spi_writenb (tbuf, 3);
}

// General SPI decription
void tmc40bit_writeInt(u8 motor, uint8 address, int value)
{
    char tbuf[5];
    tbuf[0] = address | 0x80;
    tbuf[1] = 0xFF & (value>>24);
    tbuf[2] = 0xFF & (value>>16);
    tbuf[3] = 0xFF & (value>>8);
    tbuf[4] = 0xFF & value;

    bcm2835_spi_writenb (tbuf, 5);
}

int tmc40bit_readInt(u8 motor, uint8 address)
{
    char tbuf[5], rbuf[5];
    int value;
	// clear write bit
	tbuf[0] = address & 0x7F;
    tbuf[1] = 0;
    tbuf[2] = 0;
    tbuf[3] = 0;
    tbuf[4] = 0;
    
    bcm2835_spi_transfernb (tbuf, rbuf, 5);

	value =rbuf[1];
	value <<= 8;
	value |= rbuf[2];
	value <<= 8;
	value |= rbuf[3];
	value <<= 8;
	value |= rbuf[4];

	return value;
}