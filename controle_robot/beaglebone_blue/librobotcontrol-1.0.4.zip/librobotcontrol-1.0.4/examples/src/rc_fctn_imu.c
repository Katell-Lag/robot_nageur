/**
 * @file rc_fctn_imu.c
 * @example    rc_fctn_imu
 *
 *specific code, to control one arm (3 motors)
 *using 3 IMU, 3 encoder, 3 escs
 *
 * @author     Anna AGOBIAN & Katell LAGATTU
 * @date       3/20/2018
 */

#include <stdio.h>
#include <getopt.h>
#include <stdlib.h> // for atoi
#include <signal.h>
#include <rc/time.h>
#include <rc/dsm.h>
#include <rc/servo.h>
#include <rc/encoder.h>

/**
 * @file rc_test_dmp.c
 * @example    rc_test_dmp
 *
 * @brief      serves as an example of how to use the MPU in DMP mode
 *
 *
 *
 * @author     James Strawson
 * @date       1/29/2018
 */


#include <stdio.h>
#include <getopt.h>
#include <signal.h>
#include <stdlib.h> // for atoi() and exit()
#include <rc/mpu.h>
#include <rc/time.h>

// bus for Robotics Cape and BeagleboneBlue is 2, interrupt pin is on gpio3.21
// change these for your platform
#define I2C_BUS 2
#define GPIO_INT_PIN_CHIP 3
#define GPIO_INT_PIN_PIN  21

// Global Variables
static int running = 0;
static int silent_mode = 0;
static int show_accel = 0;
static int show_gyro  = 0;
static int enable_mag = 0;
static int show_compass = 0;
static int show_temp  = 0;
static int show_quat  = 0;
static int show_tb = 0;
static int orientation_menu = 0;
static rc_mpu_data_t data;

// local functions
static rc_mpu_orientation_t __orientation_prompt(void);
static void __print_usage(void);
static void __print_data(void);
static void __print_header(void);
void IMU_parameter(void);
//static int running = 0;

typedef enum test_mode_t{
	DISABLED,
	SWEEP,
	SWEEP_bis,
	THROTTLE
}test_mode_t;

/**
 * Printed if some invalid argument was given, or -h option given.
 */
static void __print_usage(void)
{

	
	
	printf("\n");
	printf(" Motors options\n");
	printf(" -h             Print this help message \n\n");
	printf(" -c {channel}   Specify one channel to be driven from 1-8.\n");
	printf("                Otherwise all channels will be driven equally\n");
	printf(" -a             Specify the angle limit \n\n");
	printf(" -f {hz}        Specify pulse frequency, otherwise 50hz is used\n");
	printf(" -s {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -b {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -t {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf("                {max} can be between 0 & 1.0\n");
	printf(" -m {min,max}   Set the pulse width range in microseconds, default is 1000,2000\n");
	printf("                if this option is not given. Use -m 1120,1920 for DJI ESCs.\n");
	printf(" -l		choose loop (initialisazion or loop)\n");
	printf("\n");
	printf("sample use to control DJI ESC channel 2 with DSM radio channel 1:\n");
	printf("   rc_moteurs_synchros -c 8 -a -250000 -f 400 -s 1.0 -m 1100,1500\n\n");

	return;
}

/**
 * This is the IMU interrupt function.
 */
static void __print_data(void)
{
	printf("\r");
	printf(" ");

	if(show_compass){
		printf("   %6.1f   |", data.compass_heading_raw*RAD_TO_DEG);
		printf("   %6.1f   |", data.compass_heading*RAD_TO_DEG);
	}
	if(show_quat && enable_mag){
		// print fused quaternion
		printf(" %4.1f %4.1f %4.1f %4.1f |",	data.fused_quat[QUAT_W], \
							data.fused_quat[QUAT_X], \
							data.fused_quat[QUAT_Y], \
							data.fused_quat[QUAT_Z]);
	}
	else if(show_quat){
		// print quaternion
		printf(" %4.1f %4.1f %4.1f %4.1f |",	data.dmp_quat[QUAT_W], \
							data.dmp_quat[QUAT_X], \
							data.dmp_quat[QUAT_Y], \
							data.dmp_quat[QUAT_Z]);
	}
	if(show_tb && enable_mag){
		// print fused TaitBryan Angles
		printf("%6.1f %6.1f %6.1f |",	data.fused_TaitBryan[TB_PITCH_X]*RAD_TO_DEG,\
						data.fused_TaitBryan[TB_ROLL_Y]*RAD_TO_DEG,\
						data.fused_TaitBryan[TB_YAW_Z]*RAD_TO_DEG);
	}
	else if(show_tb){
		// print TaitBryan angles
		printf("%6.1f %6.1f %6.1f |",	data.dmp_TaitBryan[TB_PITCH_X]*RAD_TO_DEG,\
						data.dmp_TaitBryan[TB_ROLL_Y]*RAD_TO_DEG,\
						data.dmp_TaitBryan[TB_YAW_Z]*RAD_TO_DEG);
	}
	if(show_accel){
		printf(" %5.2f %5.2f %5.2f |",	data.accel[0],\
						data.accel[1],\
						data.accel[2]);
	}
	if(show_gyro){
		printf(" %5.1f %5.1f %5.1f |",	data.gyro[0],\
						data.gyro[1],\
						data.gyro[2]);
	}
	if(show_temp){
		rc_mpu_read_temp(&data);
		printf(" %6.2f |", data.temp);
	}
	fflush(stdout);
	return;
}

/**
 * Based on which data is marked to be printed, print the correct labels. this
 * is printed only once and the actual data is updated on the next line.
 */
static void __print_header(void)
{
	printf(" ");
	if(show_compass){
		printf("Raw Compass |");
		printf("FilteredComp|");
	}
	if(enable_mag){
		if(show_quat) printf("   Fused Quaternion  |");
		if(show_tb) printf(" FusedTaitBryan(deg) |");
	} else{
		if(show_quat) printf("    DMP Quaternion   |");
		if(show_tb) printf(" DMP TaitBryan (deg) |");
	}
	if(show_accel) printf(" Accel XYZ (m/s^2) |");
	if(show_gyro)  printf("  Gyro XYZ (deg/s) |");
	if(show_temp)  printf(" Temp(C)|");

	printf("\n");
}

/**
 * @brief      interrupt handler to catch ctrl-c
 */
static void __signal_handler(__attribute__ ((unused)) int dummy)
{
	running=0;
	return;
}

/**
 * If the user selects the -o option for orientation selection, this menu will
 * displayed to prompt the user for which orientation to use. It will return a
 * valid rc_mpu_orientation_t when a number 1-6 is given or quit when 'q' is
 * pressed. On other inputs the user will be allowed to enter again.
 *
 * @return     the orientation enum chosen by user
 */
rc_mpu_orientation_t __orientation_prompt(){
	int c;

	printf("\n");
	printf("Please select a number 1-6 corresponding to the\n");
	printf("orientation you wish to use. Press 'q' to exit.\n\n");
	printf(" 1: ORIENTATION_Z_UP\n");
	printf(" 2: ORIENTATION_Z_DOWN\n");
	printf(" 3: ORIENTATION_X_UP\n");
	printf(" 4: ORIENTATION_X_DOWN\n");
	printf(" 5: ORIENTATION_Y_UP\n");
	printf(" 6: ORIENTATION_Y_DOWN\n");
	printf(" 7: ORIENTATION_X_FORWARD\n");
	printf(" 8: ORIENTATION_X_BACK\n");

	while ((c = getchar()) != EOF){
		switch(c){
		case '1':
			return ORIENTATION_Z_UP;
			break;
		case '2':
			return ORIENTATION_Z_DOWN;
			break;
		case '3':
			return ORIENTATION_X_UP;
			break;
		case '4':
			return ORIENTATION_X_DOWN;
			break;
		case '5':
			return ORIENTATION_Y_UP;
			break;
		case '6':
			return ORIENTATION_Y_DOWN;
			break;
		case '7':
			return ORIENTATION_X_FORWARD;
			break;
		case '8':
			return ORIENTATION_X_BACK;
			break;
		case 'q':
			printf("Quitting\n");
			exit(0);
		case '\n':
			break;
		default:
			printf("invalid input\n");
			break;
		}
	}
	return 0;
}

/**
 * main() serves to parse user options, initialize the imu and interrupt
 * handler, and wait for the rc_get_state()==EXITING condition before exiting
 * cleanly. The imu_interrupt function print_data() is what actually prints new
 * imu data to the screen after being set with rc_mpu_set_dmp_callback().
 *
 * @param[in]  argc  The argc
 * @param      argv  The argv
 *
 * @return     0 on success -1 on failure
 */
void IMU_parameter()
{
	//------------------//
	//--IMU PARAMETERS--//
	//------------------//

	int c, sample_rate, priority;
	int show_something = 0; // set to 1 when any show data option is given.

	// start with default config and modify based on options
	rc_mpu_config_t conf = rc_mpu_default_config();
	conf.i2c_bus = I2C_BUS;
	conf.gpio_interrupt_pin_chip = GPIO_INT_PIN_CHIP;
	conf.gpio_interrupt_pin = GPIO_INT_PIN_PIN;

	// parse arguments
	opterr = 0;
	printf("\n IMU options\n");
	printf("-r {rate}	Set sample rate in HZ (default 100)\n");
	printf("		Sample rate must be a divisor of 200\n");
	printf("-m		Enable Magnetometer\n");
	printf("-b		Enable Reading Magnetometer before ISR (default after)\n");
	printf("-c		Show raw compass angle\n");
	printf("-a		Print Accelerometer Data\n");
	printf("-g		Print Gyro Data\n");
	printf("-T		Print Temperature\n");
	printf("-t		Print TaitBryan Angles\n");
	printf("-q		Print Quaternion Vector\n");
	printf("-p {prio}	Set Interrupt Priority and FIFO scheduling policy (requires root)\n");
	printf("-w		Print I2C bus warnings\n");
	printf("-o		Show a menu to select IMU orientation\n");
	printf("-h		Print this help message\n\n");
	printf("\n\n Please enter your parameters : \n");
	
	int bytes_read;
	int size=10;
	char *string;
	string= (char *) malloc(size);
	
	while ((c=getline(&string,&size, stdin)!=-1 ){
		switch (c){
		case 's':
			silent_mode = 1;
			show_something = 1;
			break;
		case 'r': // sample rate option
			sample_rate = atoi(optarg);
			if(sample_rate>200 || sample_rate<4){
				printf("sample_rate must be between 4 & 200");
				return -1;
			}
			conf.dmp_sample_rate = sample_rate;
			break;
		case 'p': // priority option
			priority = atoi(optarg);
			conf.dmp_interrupt_priority = priority;
			conf.dmp_interrupt_sched_policy = SCHED_FIFO;
			break;
		case 'm': // magnetometer option
			show_something = 1;
			enable_mag = 1;
			conf.enable_magnetometer = 1;
			break;
		case 'b': // magnetometer option
			conf.read_mag_after_callback = 0;
			break;
		case 'c': // compass option
			show_something = 1;
			enable_mag = 1;
			show_compass = 1;
			conf.enable_magnetometer = 1;
			break;
		case 'a': // show accelerometer option
			show_something = 1;
			show_accel = 1;
			conf.dmp_fetch_accel_gyro=1;
			break;
		case 'g': // show gyro option
			show_something = 1;
			show_gyro = 1;
			conf.dmp_fetch_accel_gyro=1;
			break;
		case 'q': // show quaternion option
			show_something = 1;
			show_quat = 1;
			break;
		case 't': // show TaitBryan angle option
			show_something = 1;
			show_tb = 1;
			break;
		case 'T': // read thermometer option
			show_something = 1;
			show_temp = 1;
			break;
		case 'w': // print warnings
			conf.show_warnings=1;
			break;
		case 'o': // let user select imu orientation
			orientation_menu=1;
			break;
		case 'h': // show help option
			__print_usage();
			return -1;
			break;
		default:
			printf("opt: %c\n",c);
			printf("invalid argument\n");
			__print_usage();
			return -1;
			break;
		}
	}
	/*
	// user didn't give an option to show anything. Print warning and return.
	if(show_something==0){
		__print_usage();
		printf("please enable an option to print some data\n");
		return -1;
	}
	// If the user gave the -o option to select an orientation then prompt them
	if(orientation_menu){
		conf.orient=__orientation_prompt();
	}
	// set signal handler so the loop can exit cleanly
	signal(SIGINT, __signal_handler);
	running = 1;

	// now set up the imu for dmp interrupt operation
	if(rc_mpu_initialize_dmp(&data, conf)){
		printf("rc_mpu_initialize_failed\n");
		return -1;
	}
	// write labels for what data will be printed and associate the interrupt
	// function to print data immediately after the header.
	__print_header();
	if(!silent_mode) rc_mpu_set_dmp_callback(&__print_data);
	//now just wait, print_data() will be called by the interrupt
	while(running)	rc_usleep(100000);

	// shut things down
	rc_mpu_power_off();
	printf("\n");
	fflush(stdout);*/
}






//----------------------------------------------------------------------------//
//----------------------------------MOTORS------------------------------------//
//----------------------------------------------------------------------------//
// INDICATIVE MESSAGE 
/*
static void __print_usage(void)
{
	printf("\n");
	printf(" Options\n");
	printf(" -h             Print this help message \n\n");
	printf(" -c {channel}   Specify one channel to be driven from 1-8.\n");
	printf("                Otherwise all channels will be driven equally\n");
	printf(" -a             Specify the angle limit \n\n");
	printf(" -f {hz}        Specify pulse frequency, otherwise 50hz is used\n");
	printf(" -s {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -b {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -t {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf("                {max} can be between 0 & 1.0\n");
	printf(" -m {min,max}   Set the pulse width range in microseconds, default is 1000,2000\n");
	printf("                if this option is not given. Use -m 1120,1920 for DJI ESCs.\n");
	printf(" -l		choose loop (initialisazion or loop)\n");
	printf("\n");
	printf("sample use to control DJI ESC channel 2 with DSM radio channel 1:\n");
	printf("   rc_moteurs_synchros -c 8 -a -250000 -f 400 -s 1.0 -m 1100,1500\n\n");
	}

// interrupt handler to catch ctrl-c
static void __signal_handler(__attribute__ ((unused)) int dummy)
{
	running=0;
	return;
}
*/
int main(int argc, char *argv[])
{
	//---------------------//
	//--MOTORS PARAMETERS--//
	//--------------------//
	int c,i,ret;		// misc variables
	double sweep_limit = 0;	// max throttle allowed when sweeping
	double thr = 0;		// normalized throttle
	double thr2 = 0;
	double thr3 = 0;
	int ch = 0;		// channel to test, 0 means all channels
	double dir = 1; 	// switches between 1 & -1 in sweep mode
	double dir2 = 1;
	double dir3 = 1;
	test_mode_t mode;	// current operating mode
	int frequency_hz = 50;	// default 50hz frequency to send pulses
	int wakeup_en = 1;	// wakeup period enabled by default 1
	double wakeup_s = 5;	// wakeup period in seconds 3
	double wakeup_val = 0.0;// wakeup value
	double angle =0;
	int min_us = RC_ESC_DEFAULT_MIN_US;
	int max_us = RC_ESC_DEFAULT_MAX_US;
	int objectif1 = 360;
	float objectif_final1 = -400000*objectif1/90;
	int objectif2 = 90;
	float objectif_final2 = -400000*objectif2/90;
	int indice  = 0;
	double loop_level=0; 	// initialization level


	int i1;
	IMU_parameter();

	//-----------------------------------------//
	//-------------INITIALISATION--------------//
	//-----------------------------------------//
	// initialize hardware first
	if(rc_encoder_init()){
		fprintf(stderr,"ERROR: failed to run rc_encoder_init\n");
		return -1;
	}

	// set signal handler so the loop can exit cleanly
	signal(SIGINT, __signal_handler);
	running=1;

	printf("\nRaw encoder positions\n");
	printf("      E1   |");
	printf("      E2   |");
	printf("      E3   |");
	printf("      E4   |");
	printf(" \n");

	printf("\r");
	for(i1=1;i1<=4;i1++){
		printf("%10d |", rc_encoder_read(i1));
	}

	// start with mode as disabled
	mode = DISABLED;

	//-----------------------------------//
	//----------- PARAMETERS ------------//
	//-----------------------------------//
	// parse arguments
	opterr = 0;
	while ((c = getopt(argc, argv, "c:a:f:s:b:t:m:l:")) != -1){
		switch(c){
		// channel option
		case 'c':
			ch = atoi(optarg);
			if(ch<RC_SERVO_CH_MIN || ch>RC_SERVO_CH_MAX){
				fprintf(stderr,"ERROR channel option must be between %d and %d\n", RC_SERVO_CH_MIN, RC_SERVO_CH_MAX);
				return -1;
			}
			break;
		// angle limit
		case 'a':
			angle = atof(optarg);
			break;

		// pulse frequency option
		case 'f':
			frequency_hz = atoi(optarg);
			if(frequency_hz<1){
				fprintf(stderr,"Frequency option must be >=1\n");
				return -1;
			}
			break;
		// sweep mode option
		case 's':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = SWEEP;
			//thr=1;thr2=1;thr3=1;
			thr=0;thr2=0;thr3=0;
			dir=1;
			break;

		// sweep mode option
		case 'b':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = SWEEP_bis;
			thr=1;thr2=1;thr3=1;
			dir=1;
			break;
		// throttle mode option
		case 't':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = THROTTLE;
			thr=0;
			dir=1;
			break;


		// min/max option
		case 'm':
			ret = sscanf(optarg, "%d,%d", &min_us, &max_us);
			if(ret!=2){
				fprintf(stderr, "-m min/max option must have the form: -m 1120,1920\n");
				return -1;
			}
			break;

		// Loop configuration
		case 'l':
			loop_level = atof(optarg);
			if( (loop_level)<=0.0)
			{
				wakeup_en=1;
			}
			else if (loop_level>=1)
			{
				wakeup_en=0;
			}
			break;

		default:
			printf("\nInvalid Argument \n");
			__print_usage();
			return -1;

		}
	}

	// if the user didn't give enough arguments, exit
	if(mode==DISABLED){
		fprintf(stderr,"\nNot enough input arguments\n");
		__print_usage();
		return -1;
	}

	// set signal handler so the loop can exit cleanly
	signal(SIGINT, __signal_handler);
	running=1;

	
	//--------------------------------------//
	//-----INITIALISATION PRU/ESC/UART------//
	//--------------------------------------//
	// initialize PRU and make sure power rail is OFF
	if(rc_servo_init()) return -1;
/*	if(wakeup_en){
		if(rc_servo_set_esc_range(1490,1500, 1)) return -1;
		if(rc_servo_set_esc_range(1490,1500,  2)) return -1;
		if(rc_servo_set_esc_range(1490,1500,  3)) return -1;
	}*/
	if(rc_servo_set_esc_range(1400,1600, 1)) return -1;
	if(rc_servo_set_esc_range(1400,1600, 2)) return -1;
	if(rc_servo_set_esc_range(min_us,max_us, ch)) return -1;
	rc_servo_power_rail_en(0);

	// if driving an ESC, send throttle of 0 first
	// otherwise it will go into calibration mode
	if(wakeup_en){
		printf("waking ESC up from idle for 3 seconds\n");
		for(i=0;i<=frequency_hz*wakeup_s;i++){
			if(running==0) return 0;
			printf("INITIALISATION!!!!!!!!!\n");
			if((rc_servo_send_esc_pulse_normalized(1,wakeup_val)==-1)&&(rc_servo_send_esc_pulse_normalized(2,wakeup_val)==-1)&&(rc_servo_send_esc_pulse_normalized(ch,wakeup_val)==-1)) {
				printf("Tous les moteurs iniiiiiiiiiit\n");
				return -1;}
			
			/*rc_servo_send_esc_pulse_normalized(1, wakeup_val);
			printf("MOTEUR 1 INITIALISE\n");
			rc_servo_send_esc_pulse_normalized(2, wakeup_val);
			printf("MOTEUR2 INIT\n");
			rc_servo_send_esc_pulse_normalized(3, wakeup_val);
			printf("MOTEUR3 INIT\n");*/
			rc_usleep(1000000/frequency_hz);
		}
		printf("done with wakeup period\n");
	}


	//--------------------------------//
	//------------MAIN LOOP-----------//
	//--------------------------------//
	// Main loop runs at frequency_hz
	while(running){
		switch(mode){
		case SWEEP:
			// increase or decrease position each loop
			// scale with frequency
			thr += dir * sweep_limit / frequency_hz;

			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}

			else if(thr < 0){
				thr = 0;
				dir = -1;
			}
			// send result
			printf("\r");
			printf("\nTHR1= %lf\n",thr);


			//printf("%lf \n",thr);
			 rc_servo_send_esc_pulse_normalized(ch,thr); //moteur epaule
		
                        // printf("min_us: %lf\n", min_us);
		
			 //if ((rc_encoder_read(4)<=- 0) && (rc_encoder_read(4) >= -450000)){ //COMMANDE MOTEUR BRAS
			  if (rc_encoder_read(1) >=- 480000 && rc_encoder_read(4)<=- 600000){
			  //if (-1<0){
				 thr2 += dir2*sweep_limit / frequency_hz;
				 if (thr2 > sweep_limit){
					 thr2 = sweep_limit;
					 dir2 = -1;
				}
				else if (thr2<0){
					thr2 = 0;
					dir2 = -1;
				}
				 //printf("MOTEUR 1");
				 printf("THR2= %lf\n",thr2);
			 	rc_servo_send_esc_pulse_normalized(1, thr2); //moteur bras
			 }

		/*	 if (rc_encoder_read(1) <= 0 && rc_encoder_read(4)<=- 1000000){
				rc_servo_send_esc_pulse_normalized(1, 1-thr2);
				printf("MARCHE ARRIERE TOUTE\n");
			 }*/


		       // if ((rc_encoder_read(4) <= -0) && (rc_encoder_read(4) >= -450000)){ //COMMANDE MOTEUR AVANT BRAS
		          // if (-1<0){
			         if (rc_encoder_read(2) <= 240000 && rc_encoder_read(4)<=-600000){
				 thr3 +=dir3*sweep_limit /frequency_hz;
				 if (thr3 > sweep_limit){
					 thr3 = sweep_limit;
					 dir3 = -1;
					}
				 else if (thr3 < 0){
					 thr3 = 0;
					 dir3 = -1;
				 }
				 //printf("MOTEUR 2");
				 printf("THR3= %lf\n",1-thr3);
				rc_servo_send_esc_pulse_normalized(2,1- thr3); //moteur avant bras
			 }
			if (rc_encoder_read(2) >= 240000){ //ARRET MOTEUR 2
				printf("ARRET MOTEUR 2");
				rc_servo_send_esc_pulse_normalized(2, 0.5);
				//rc_servo_send_esc_pulse_normalized(1, 0.5);
				

			}
			if (rc_encoder_read(1)<=-480000 && rc_encoder_read(4) >= -1000000){ //ARRET MOTEUR1
				rc_servo_send_esc_pulse_normalized(1, 0.5);
			}

		//	if (rc_encoder_read(1) >= 0 && rc_encoder_read(4) <= 1200000){
			//	rc_servo_send_esc_pulse_normalized(1, 0.5);
		//	}
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			//going to a specified angle
		        
			printf("%10d", indice);
			if  ((rc_encoder_read(4)<=-100000000000) && (indice == 0))
			{
				
				//rc_servo_send_esc_pulse_normalized(ch, -0.1);
				//rc_usleep(5000000);
				//for(i1=1;i1<=100000000;i1++);
			        for(i1=1;i1<=4;i1++){
					printf("%10d |", rc_encoder_read(i1));
				}
				indice = 1;
				printf("objectif 1 atteint");
				return -1;
				
				
			
				

			}
		        /*if (indice == 1){
			for(i1=1;i1<=10000000;i1++){
				rc_servo_send_esc_pulse_normalized(ch, -0.1);
				rc_usleep(1000000/frequency_hz);
				}
			}
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			if (rc_encoder_read(4)<=objectif_final2 && (indice == 1))
			{
				printf("objectif2 atteint");
				for(i1=1;i1<=4;i1++){
					printf("%10d |", rc_encoder_read(i1));
				}
				return -1;
			
			}*/
			break;



		case SWEEP_bis:
			// increase or decrease position each loop
			// scale with frequency
			thr += dir * sweep_limit / frequency_hz;
			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}
			else if(thr < 0){
				thr = 0;
				dir = 1;
			}
			// send result
			rc_servo_send_esc_pulse_normalized(ch,thr);
			//rc_usleep(500);

			printf("\r");
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			//going to a specified angle
			if (rc_encoder_read(4)>=angle)
			{
				printf("1 tour effectue \n");
				return -1;

			}
			break;	

		case THROTTLE:
			// increase or decrease position each loop
			// scale with frequency
			
			thr = dir*sweep_limit/ frequency_hz;
			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}
			else if(thr < sweep_limit){
				thr = sweep_limit;
				dir = 1;
			}
			// send result
			printf("%lf",thr);
			rc_servo_send_esc_pulse_normalized(ch,thr);
			//rc_usleep(500);
			printf("\r");
			break;		

		default:
			fprintf(stderr,"ERROR unhandled mode\n");
			return -1;
		}

		// sleep roughly enough to maintain frequency_hz
		rc_usleep(1000000/frequency_hz);
	}

	//----------------------//
	//--------CLEANUP-------//
	//----------------------//
	// cleanup
	//rc_servo_send_esc_pulse_normalized(ch,-0.1);
	//rc_servo_send_esc_pulse_normalized(1, -0.1);
	//rc_servo_send_esc_pulse_normalized(2, -0.1);
	rc_usleep(50000);
	if(wakeup_en){
		rc_servo_cleanup();
	}
	rc_encoder_cleanup();
	printf("\n\n");
	return 0;
}

