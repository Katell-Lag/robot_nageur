/**
 * @file rc_test_esc.c
 * @example    rc_test_esc
 *
 *
 * Demonstrates use of pru to control servos and ESCs with pulses. This program
 * operates in 4 different modes. See the option list below for how to select an
 * operational mode from the command line.
 *
 * SERVO: uses rc_servo_send_pulse_normalized() to set one or all servo
 * positions to a value from -1.5 to 1.5 corresponding to their extended range.
 * -1 to 1 is considered the "safe" normal range as some servos will not go
 * beyond this. Test your servos incrementally to find their safe range.
 *
 * ESC: For unidirectional brushless motor speed controllers specify a range
 * from 0 to 1 as opposed to the bidirectional servo range. Be sure to run the
 * calibrate_esc example first to make sure the ESCs are calibrated to the right
 * pulse range. This mode uses the rc_servo_send_esc_pulse_normalized() function.
 *
 * WIDTH: You can also specify your own pulse width in microseconds (us).
 * This uses the rc_servo_send_pulse_us() function.
 *
 * SWEEP: This is intended to gently sweep a servo back and forth about the
 * center position. Specify a range limit as a command line argument as
 * described below. This also uses the rc_servo_send_pulse_normalized()
 * function.
 *
 *
 *
 * @author     James Strawson
 * @date       3/20/2018
 */

#include <stdio.h>
#include <getopt.h>
#include <stdlib.h> // for atoi
#include <signal.h>
#include <rc/time.h>
#include <rc/dsm.h>
#include <rc/servo.h>
#include <rc/encoder.h>


static int running = 0;

typedef enum test_mode_t{
	DISABLED,
	SWEEP,
	SWEEP_bis,
	THROTTLE
}test_mode_t;


static void __print_usage(void)
{
	printf("\n");
	printf(" Options\n");
	printf(" -h             Print this help messege \n\n");
	printf(" -c {channel}   Specify one channel to be driven from 1-8.\n");
	printf("                Otherwise all channels will be driven equally\n");
	printf(" -a             Specify the angle limit \n\n");
	printf(" -f {hz}        Specify pulse frequency, otherwise 50hz is used\n");
	printf(" -s {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -b {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf(" -t {max}       Gently sweep throttle from 0 to {max} back to 0 again\n");
	printf("                {max} can be between 0 & 1.0\n");
	printf(" -m {min,max}   Set the pulse width range in microseconds, default is 1000,2000\n");
	printf("                if this option is not given. Use -m 1120,1920 for DJI ESCs.\n");
	printf(" -l		choose loop (initialisazion or loop)\n");
	printf("\n");
	printf("sample use to control DJI ESC channel 2 with DSM radio channel 1:\n");
	printf("   rc_moteurs_synchros -c 8 -a -250000 -f 400 -s 1.0 -m 1100,1500\n\n");
	}

// interrupt handler to catch ctrl-c
static void __signal_handler(__attribute__ ((unused)) int dummy)
{
	running=0;
	return;
}

int main(int argc, char *argv[])
{
	int c,i,ret;		// misc variables
	double sweep_limit = 0;	// max throttle allowed when sweeping
	double thr = 0;		// normalized throttle
	double thr2 = 0;
	double thr3 = 0;
	int ch = 0;		// channel to test, 0 means all channels
	double dir = 1; 	// switches between 1 & -1 in sweep mode
	double dir2 = 1;
	double dir3 = 1;
	test_mode_t mode;	// current operating mode
	int frequency_hz = 50;	// default 50hz frequency to send pulses
	int wakeup_en = 1;	// wakeup period enabled by default 1
	double wakeup_s = 5;	// wakeup period in seconds 3
	double wakeup_val = 0.0;// wakeup value
	double angle =0;
	int min_us = RC_ESC_DEFAULT_MIN_US;
	int max_us = RC_ESC_DEFAULT_MAX_US;
	int objectif1 = 360;
	float objectif_final1 = -400000*objectif1/90;
	int objectif2 = 90;
	float objectif_final2 = -400000*objectif2/90;
	int indice  = 0;
	double loop_level=0; 	// initialization level


	int i1;

	// initialize hardware first
	if(rc_encoder_init()){
		fprintf(stderr,"ERROR: failed to run rc_encoder_init\n");
		return -1;
	}

	// set signal handler so the loop can exit cleanly
	signal(SIGINT, __signal_handler);
	running=1;

	printf("\nRaw encoder positions\n");
	printf("      E1   |");
	printf("      E2   |");
	printf("      E3   |");
	printf("      E4   |");
	printf(" \n");

	printf("\r");
	for(i1=1;i1<=4;i1++){
		printf("%10d |", rc_encoder_read(i1));
	}

	// start with mode as disabled
	mode = DISABLED;

	// parse arguments
	opterr = 0;
	while ((c = getopt(argc, argv, "c:a:f:s:b:t:m:l:")) != -1){
		switch(c){
		// channel option
		case 'c':
			ch = atoi(optarg);
			if(ch<RC_SERVO_CH_MIN || ch>RC_SERVO_CH_MAX){
				fprintf(stderr,"ERROR channel option must be between %d and %d\n", RC_SERVO_CH_MIN, RC_SERVO_CH_MAX);
				return -1;
			}
			break;
		// angle limit
		case 'a':
			angle = atof(optarg);
			break;

		// pulse frequency option
		case 'f':
			frequency_hz = atoi(optarg);
			if(frequency_hz<1){
				fprintf(stderr,"Frequency option must be >=1\n");
				return -1;
			}
			break;
		// sweep mode option
		case 's':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = SWEEP;
			//thr=1;thr2=1;thr3=1;
			thr=0;thr2=0;thr3=0;
			dir=1;
			break;

		// sweep mode option
		case 'b':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = SWEEP_bis;
			thr=1;thr2=1;thr3=1;
			dir=1;
			break;
		// throttle mode option
		case 't':
			// make sure only one mode in requested
			if(mode!=DISABLED){
				fprintf(stderr,"ERROR please select only one mode to use\n");
				__print_usage();
				return -1;
			}
			sweep_limit = atof(optarg);
			if(sweep_limit>1.0 || sweep_limit<0){
				fprintf(stderr,"ERROR: Sweep limit must be from 0 to 1.0\n");
				return -1;
			}
			mode = THROTTLE;
			thr=0;
			dir=1;
			break;


		// min/max option
		case 'm':
			ret = sscanf(optarg, "%d,%d", &min_us, &max_us);
			if(ret!=2){
				fprintf(stderr, "-m min/max option must have the form: -m 1120,1920\n");
				return -1;
			}
			break;

		// Loop configuration
		case 'l':
			loop_level = atof(optarg);
			if( (loop_level)<=0.0)
			{
				wakeup_en=1;
			}
			else if (loop_level>=1)
			{
				wakeup_en=0;
			}
			break;

		default:
			printf("\nInvalid Argument \n");
			__print_usage();
			return -1;

		}
	}

	// if the user didn't give enough arguments, exit
	if(mode==DISABLED){
		fprintf(stderr,"\nNot enough input arguments\n");
		__print_usage();
		return -1;
	}

	// set signal handler so the loop can exit cleanly
	signal(SIGINT, __signal_handler);
	running=1;

	// initialize PRU and make sure power rail is OFF
	if(rc_servo_init()) return -1;
/*	if(wakeup_en){
		if(rc_servo_set_esc_range(1490,1500, 1)) return -1;
		if(rc_servo_set_esc_range(1490,1500,  2)) return -1;
		if(rc_servo_set_esc_range(1490,1500,  3)) return -1;
	}*/
	if(rc_servo_set_esc_range(1400,1600, 1)) return -1;
	if(rc_servo_set_esc_range(1400,1600, 2)) return -1;
	if(rc_servo_set_esc_range(min_us,max_us, ch)) return -1;
	rc_servo_power_rail_en(0);

	// if driving an ESC, send throttle of 0 first
	// otherwise it will go into calibration mode
	if(wakeup_en){
		printf("waking ESC up from idle for 3 seconds\n");
		for(i=0;i<=frequency_hz*wakeup_s;i++){
			if(running==0) return 0;
			printf("INITIALISATION!!!!!!!!!\n");
			if((rc_servo_send_esc_pulse_normalized(1,wakeup_val)==-1)&&(rc_servo_send_esc_pulse_normalized(2,wakeup_val)==-1)&&(rc_servo_send_esc_pulse_normalized(ch,wakeup_val)==-1)) {
				printf("Tous les moteurs iniiiiiiiiiit\n");
				return -1;}
			
			/*rc_servo_send_esc_pulse_normalized(1, wakeup_val);
			printf("MOTEUR 1 INITIALISE\n");
			rc_servo_send_esc_pulse_normalized(2, wakeup_val);
			printf("MOTEUR2 INIT\n");
			rc_servo_send_esc_pulse_normalized(3, wakeup_val);
			printf("MOTEUR3 INIT\n");*/
			rc_usleep(1000000/frequency_hz);
		}
		printf("done with wakeup period\n");
	}


	// Main loop runs at frequency_hz
	while(running){
		switch(mode){
		case SWEEP:
			// increase or decrease position each loop
			// scale with frequency
			thr += dir * sweep_limit / frequency_hz;

			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}

			else if(thr < 0){
				thr = 0;
				dir = -1;
			}
			// send result
			printf("\r");
			printf("\nTHR1= %lf\n",thr);


			//printf("%lf \n",thr);
			 rc_servo_send_esc_pulse_normalized(ch,thr); //moteur epaule
		
                        // printf("min_us: %lf\n", min_us);
		
			 //if ((rc_encoder_read(4)<=- 0) && (rc_encoder_read(4) >= -450000)){ //COMMANDE MOTEUR BRAS
			  if (rc_encoder_read(1) >=- 480000 && rc_encoder_read(4)<=- 600000){
			  //if (-1<0){
				 thr2 += dir2*sweep_limit / frequency_hz;
				 if (thr2 > sweep_limit){
					 thr2 = sweep_limit;
					 dir2 = -1;
				}
				else if (thr2<0){
					thr2 = 0;
					dir2 = -1;
				}
				 //printf("MOTEUR 1");
				 printf("THR2= %lf\n",thr2);
			 	rc_servo_send_esc_pulse_normalized(1, thr2); //moteur bras
			 }

		/*	 if (rc_encoder_read(1) <= 0 && rc_encoder_read(4)<=- 1000000){
				rc_servo_send_esc_pulse_normalized(1, 1-thr2);
				printf("MARCHE ARRIERE TOUTE\n");
			 }*/


		       // if ((rc_encoder_read(4) <= -0) && (rc_encoder_read(4) >= -450000)){ //COMMANDE MOTEUR AVANT BRAS
		          // if (-1<0){
			         if (rc_encoder_read(2) <= 240000 && rc_encoder_read(4)<=-600000){
				 thr3 +=dir3*sweep_limit /frequency_hz;
				 if (thr3 > sweep_limit){
					 thr3 = sweep_limit;
					 dir3 = -1;
					}
				 else if (thr3 < 0){
					 thr3 = 0;
					 dir3 = -1;
				 }
				 //printf("MOTEUR 2");
				 printf("THR3= %lf\n",1-thr3);
				rc_servo_send_esc_pulse_normalized(2,1- thr3); //moteur avant bras
			 }
			if (rc_encoder_read(2) >= 240000){ //ARRET MOTEUR 2
				printf("ARRET MOTEUR 2");
				rc_servo_send_esc_pulse_normalized(2, 0.5);
				//rc_servo_send_esc_pulse_normalized(1, 0.5);
				

			}
			if (rc_encoder_read(1)<=-480000 && rc_encoder_read(4) >= -1000000){ //ARRET MOTEUR1
				rc_servo_send_esc_pulse_normalized(1, 0.5);
			}

		//	if (rc_encoder_read(1) >= 0 && rc_encoder_read(4) <= 1200000){
			//	rc_servo_send_esc_pulse_normalized(1, 0.5);
		//	}
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			//going to a specified angle
		        
			printf("%10d", indice);
			if  ((rc_encoder_read(4)<=-100000000000) && (indice == 0))
			{
				
				//rc_servo_send_esc_pulse_normalized(ch, -0.1);
				//rc_usleep(5000000);
				//for(i1=1;i1<=100000000;i1++);
			        for(i1=1;i1<=4;i1++){
					printf("%10d |", rc_encoder_read(i1));
				}
				indice = 1;
				printf("objectif 1 atteint");
				return -1;
				
				
			
				

			}
		        /*if (indice == 1){
			for(i1=1;i1<=10000000;i1++){
				rc_servo_send_esc_pulse_normalized(ch, -0.1);
				rc_usleep(1000000/frequency_hz);
				}
			}
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			if (rc_encoder_read(4)<=objectif_final2 && (indice == 1))
			{
				printf("objectif2 atteint");
				for(i1=1;i1<=4;i1++){
					printf("%10d |", rc_encoder_read(i1));
				}
				return -1;
			
			}*/
			break;



		case SWEEP_bis:
			// increase or decrease position each loop
			// scale with frequency
			thr += dir * sweep_limit / frequency_hz;
			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}
			else if(thr < 0){
				thr = 0;
				dir = 1;
			}
			// send result
			rc_servo_send_esc_pulse_normalized(ch,thr);
			//rc_usleep(500);

			printf("\r");
			for(i1=1;i1<=4;i1++){
				printf("%10d |", rc_encoder_read(i1));
			}
			//going to a specified angle
			if (rc_encoder_read(4)>=angle)
			{
				printf("1 tour effectue \n");
				return -1;

			}
			break;	

		case THROTTLE:
			// increase or decrease position each loop
			// scale with frequency
			
			thr = dir*sweep_limit/ frequency_hz;
			// reset pulse width at end of sweep
			if(thr > sweep_limit){
				thr = sweep_limit;
				dir = -1;
			}
			else if(thr < sweep_limit){
				thr = sweep_limit;
				dir = 1;
			}
			// send result
			printf("%lf",thr);
			rc_servo_send_esc_pulse_normalized(ch,thr);
			//rc_usleep(500);
			printf("\r");
			break;		

		default:
			fprintf(stderr,"ERROR unhandled mode\n");
			return -1;
		}

		// sleep roughly enough to maintain frequency_hz
		rc_usleep(1000000/frequency_hz);
	}

	// cleanup
	//rc_servo_send_esc_pulse_normalized(ch,-0.1);
	//rc_servo_send_esc_pulse_normalized(1, -0.1);
	//rc_servo_send_esc_pulse_normalized(2, -0.1);
	rc_usleep(50000);
	if(wakeup_en){
		rc_servo_cleanup();
	}
	rc_encoder_cleanup();
	printf("\n\n");
	return 0;
}

